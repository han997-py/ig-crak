
#### Install Aja Sendiri Kontol,Tinggal Pakai Aja Susah

[**WHATSAPP**](https://wa.me/6283143565470)

```
cd $HOME
git clone https://github.com/Dumai-991/Ig-Crack
cd Ig-Crack
git pull
python2 *.py
```
